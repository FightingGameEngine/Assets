;-| CPU |--------------------------------------------------------
[Command]
name = "cpu"
command = F,F,F,F,F,F,F,F,F,F
time=0

[Command]
name = "cpu"
command = B,B,B,B,B,B,B,B,B,B
time=0

[Command]
name = "cpu"
command = U,U,U,U,U,U,U,U,U,U
time=0

[Command]
name = "cpu"
command = D,D,D,D,D,D,D,D,D,D
time=0

[Command]
name = "cpu"
command = DB,DB,DB,DB,DB,DB,DB,DB,DB,DB
time=0

[Command]
name = "cpu"
command = DF,DF,DF,DF,DF,DF,DF,DF,DF,DF
time=0

[Command]
name = "cpu"
command = D,D,D,s,D,D,D,s
time=0

[Command]
name = "cpu"
command = UB,UB,UB,UB,UB,UB,UB,UB,UB,UB
time=0

[Command]
name = "cpu"
command = UF,UF,UF,UF,UF,UF,UF,UF,UF,UF
time=0

[Command]
name = "cpu"
command = a,a,a,a,a,a,a,a,a,a
time=0

[Command]
name = "cpu"
command = b,b,b,b,b,b,b,b,b,b
time=0

[Command]
name = "cpu"
command = c,c,c,c,c,c,c,c,c,c
time=0

[Command]
name = "cpu"
command = x,x,x,x,x,x,x,x,x,x
time=0

[Command]
name = "cpu"
command = y,y,y,y,y,y,y,y,y,y
time=0

[Command]
name = "cpu"
command = z,z,z,z,z,z,z,z,z,z
time=0

[Command]
name = "cpu"
command = s,s,s,s,s,s,s,s,s,s
time=0

[Command]
name = "cpu"
command = z,z,x,z,z,z,z,z,z,z,z
time=0

[Command]
name = "cpu"
command = s,x,s,s,s,s,s,s,s,s,s
time=0

;-| ���K�E�Z |--------------------------------------------------------
[Command]
name="�t���K�Qa"
Command=~F,D,B,F,D,B,a
time=40
[Command]
name="�t���K�Qb"
Command=~F,D,B,F,D,B,b
time=40

[Command]
name="�^��g��x+y"
command=~D,DF,F,D,DF,F,x+y
time=20

[Command]
name="�^��g��y"
command=~D,DF,F,D,DF,F,y
time=20

[Command]
name="�^��g��x"
command=~D,DF,F,D,DF,F,x
time=20

[Command]
name="�^��g��a+b"
command=~D,DF,F,D,DF,F,a+b
time=20

[Command]
name="�^��g��a"
command=~D,DF,F,D,DF,F,a
time=20

[Command]
name="�^��g��b"
command=~D,DF,F,D,DF,F,b
time=20
[Command]
name="�^�󗳊�a+b"
command=~D,DB,B,D,DB,B,a+b
time=20

[Command]
name="�^�󗳊�a"
command=~D,DB,B,D,DB,B,a
time=20

[Command]
name="�^�󗳊�b"
command=~D,DB,B,D,DB,B,b
time=20

[Command]
name="�^�󗳊�x"
command=~D,DB,B,D,DB,B,x
time=20

[Command]
name="�^�󗳊�y"
command=~D,DB,B,D,DB,B,y
time=20

[Command]
name="�V�n�Ԃ�"
command=~F,D,B,F,x
time=25

[Command]
name="�V�n�Ԃ�"
command=~F,D,B,F,y
time=25

[Command]
name="�t���Ka"
command=~F,DF,D,DB,B,a
time=25
[Command]
name="�t���Kb"
command=~F,DF,D,DB,B,b
time=25
[Command]
name="������"
command=~D,DF,F,x+y+a+b
time=10

[Command]
name="������"
command=~D,DF,F,c+z
time=10

[Command]
name="�ʓV��"
command=~B,DB,D,x+y+a+b
time=10

[Command]
name="�ʓV��"
command=~B,DB,D,c+z
time=10

;---------
[Command]
name="����x"
command=~F,D,DF,x
time=15


[Command]
name="����y"
command=~F,D,DF,y
time=15

[Command]
name="����a"
command=~F,D,DF,a
time=15

[Command]
name="����b"
command=~F,D,DF,b
time=15

[Command]
name="�g��x"
command=~D,DF,F,x
time=10

[Command]
name="�g��y"
command=~D,DF,F,y
time=10

[Command]
name="�՗���x"
command=~B,DB,D,x
time=10

[Command]
name="�՗���y"
command=~B,DB,D,y
time=10

[Command]
name="�g��a"
command=~D,DF,F,a
time=10

[Command]
name="�g��b"
command=~D,DF,F,b
time=10

[Command]
name="�g��y"
command=~D,DF,F,y
time=10

[Command]
name="����x"
command=~D,DB,B,x
time=10

[Command]
name="����a"
command=~D,DB,B,a
time=10

[Command]
name="����y"
command=~D,DB,B,y
time=10

[Command]
name = "X�L��a"
command=~35$D,$U,a
time = 15

[Command]
name = "X�L��b"
command=~35$D,$U,b
time = 15

;-|  |-----------------------------------------------------------
[Command]
name = "FF"     
command = F, F
time = 10

[Command]
name = "BB"     
command = B,B
time = 12

;-| ���������Z |-----------------------------------------------
[Command]
name = "kamae"
command = x+y+a
time = 1

[Command]
name = "kamae"
command = c+z
time = 1

[Command]
name = "recovery"
command = x+a
time = 1

[Command]
name = "huttobashi"
command = y+b
time = 1

[Command]
name = "ST"
command = a+y
time = 1

;-| ���o�[���� |---------------------------------------------------------
[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

;-| �{�^���ݒ� |---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

;-| �������ςȂ��ݒ�|-------------------------------------------------------
[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup" 
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

[Command]
name = "holdx"
command = /x
time = 1

[Command]
name = "holdy"
command = /y
time = 1

[Statedef -1]
[STate -1]
type=VarSet
trigger1=Var(10)=0
trigger1=Command="cpu"
var(10)=1
;---------------------------------------------------------------------------
;
[State -1,tuuten]
type = ChangeState
value = 3200
triggerall = command = "�V�n�Ԃ�"
triggerall = statetype != A
triggerall=Power>=1000
trigger1 = ctrl
trigger2=Stateno=[200,440]
trigger2=Movecontact
trigger2=Stateno!=210&&Stateno!=230&&Stateno!=200&&Stateno!=240

;---------------------------------------------------------------------------
;�ς���
[State -1,tuuten]
type = null;ChangeState
value = 1400
triggerall = command = "�^��g��x"||command = "�^��g��y"
triggerall = statetype != A
triggerall=Power>=1000
trigger1 = ctrl
trigger2=Stateno=[200,440]
trigger2=Movecontact
trigger2=Stateno!=210&&Stateno!=230&&Stateno!=200&&Stateno!=240
;---------------------------------------------------------------------------
;���̂������^�C�K�[�o�Y�[�J
[State -1,tiger]
type = ChangeState
value = 3100
triggerall = command = "�^��g��x"
triggerall = statetype != A
triggerall=Power>=1000
triggerall=Numprojid(10)=0
trigger1 = ctrl
trigger2=Stateno=[200,440]
trigger2=Movecontact
trigger2=Stateno!=210&&Stateno!=230&&Stateno!=200&&Stateno!=240
;---------------------------------------------------------------------------
;���̂������^�C�K�[�o�Y�[�J
[State -1,tiger]
type = ChangeState
value = 3101
triggerall = command = "�^��g��y"
triggerall = statetype != A
triggerall=Power>=1000
triggerall=Numprojid(10)=0
trigger1 = ctrl
trigger2=Stateno=[200,440]
trigger2=Movecontact
trigger2=Stateno!=210&&Stateno!=230&&Stateno!=200&&Stateno!=240

;---------------------------------------------------------------------------
;�ʓV��
[State -1,tuuten]
type = ChangeState
value = 1300
triggerall = command = "�ʓV��"
triggerall = statetype != A
trigger1 = ctrl
trigger2=Stateno=[200,440]
trigger2=Movecontact
trigger2=Stateno!=210&&Stateno!=230&&Stateno!=200&&Stateno!=240
;---------------------------------------------------------------------------
;�������^�C�K�[�o�Y�[�J
[State -1,tiger]
type = ChangeState
value = 3000
triggerall = command = "������"
triggerall = statetype != A
triggerall=Numprojid(10)=0
trigger1 = ctrl
trigger2=Stateno=[200,440]
trigger2=Movecontact
trigger2=Stateno!=210&&Stateno!=230&&Stateno!=200&&Stateno!=240

;---------------------------------------------------------------------------
;�^�C�K�[�o�Y�[�J�E��
[State -1,tiger]
type = ChangeState
value = 1000
triggerall = command = "�g��x"
triggerall = statetype != A
triggerall=Numprojid(10)=0
trigger1 = ctrl
trigger2=Stateno=[200,440]
trigger2=Movecontact
trigger2=Stateno!=210&&Stateno!=230&&Stateno!=200&&Stateno!=240
;---------------------------------------------------------------------------
;�^�C�K�[�o�Y�[�J�E��
[State -1,tiger]
type = ChangeState
value = 1010
triggerall = command = "�g��y"
triggerall = statetype != A
triggerall=Numprojid(10)=0
trigger1 = ctrl
trigger2=Stateno=[200,440]
trigger2=Movecontact
trigger2=Stateno!=210&&Stateno!=230&&Stateno!=200&&Stateno!=240
;---------------------------------------------------------------------------
;�`�F�X�g
[State -1,tiger]
type = ChangeState
value = 1100
triggerall = command = "�g��b"
trigger1 = ctrl
trigger2=Stateno=[200,440]
trigger2=Movecontact
trigger2=Stateno!=210&&Stateno!=230&&Stateno!=200&&Stateno!=240
trigger3=Stateno=[600,645]
trigger3=Movecontact
;---------------------------------------------------------------------------
;�`�F�X�g
[State -1,tiger]
type = ChangeState
value = 1101
triggerall = command = "�g��a"
trigger1 = ctrl
trigger2=Stateno=[200,440]
trigger2=Movecontact
trigger2=Stateno!=210&&Stateno!=230&&Stateno!=200&&Stateno!=240
trigger3=Stateno=[600,645]
trigger3=Movecontact

;---------------------------------------------------------------------------
;�՗��ӁE��
[State -1,tiger]
type = ChangeState
value = 1200
triggerall = command = "�՗���x"
triggerall = statetype != A
trigger1 = ctrl
trigger2=Stateno=[200,440]
trigger2=Movecontact
trigger2=Stateno!=210&&Stateno!=230&&Stateno!=200&&Stateno!=240
;---------------------------------------------------------------------------
;�՗��ӁE��
[State -1,tiger]
type = ChangeState
value = 1210
triggerall = command = "�՗���y"
triggerall = statetype != A
trigger1 = ctrl
trigger2=Stateno=[200,440]
trigger2=Movecontact
trigger2=Stateno!=210&&Stateno!=230&&Stateno!=200&&Stateno!=240

;---------------------------------------------------------------------------
;�_�b�V��
[State -1, Run Fwd]
type = null;ChangeState
value = 100
triggerall=Var(16)!=2
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;�o�b�N�_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
triggerall=Var(16)!=2
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 800
triggerall = command = "y"
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
trigger1 = command = "holdfwd"
trigger1 = p2bodydist X < 3
trigger1 = (p2statetype = S) || (p2statetype = C)
trigger1 = p2movetype != H
trigger2 = command = "holdback"
trigger2 = p2bodydist X < 5
trigger2 = (p2statetype = S) || (p2statetype = C)
trigger2 = p2movetype != H
;---------------------------------------------------------------------------
;����
[State -1]
type = ChangeState
value = 900
triggerall = command = "b"
triggerall = statetype = S
triggerall = ctrl
triggerall = stateno != 100
trigger1 = command = "holdfwd"
trigger1 = p2bodydist X < 3
trigger1 = (p2statetype = S) || (p2statetype = C)
trigger1 = p2movetype != H
trigger2 = command = "holdback"
trigger2 = p2bodydist X < 5
trigger2 = (p2statetype = S) || (p2statetype = C)
trigger2 = p2movetype != H

;===========================================================================
;GC��������ړ�
[State -1]
type = null;ChangeState
value = 280
triggerall = command = "recovery"||command = "c"
triggerall = Command="holdback"
trigger1 = statetype != A && Power>=1000 && Alive
trigger1 = stateno=[150,153]

;===========================================================================
;GC�O�������ړ�
[State -1]
type = null;ChangeState
value = 270
triggerall = command = "recovery"||command = "c"
trigger1 = statetype != A && Power>=1000 && Alive
trigger1 = stateno=[150,153]
;---------------------------------------------------------------------------
;GC�ӂ��Ƃ΂�
[State -1]
type = null;ChangeState
value = 260
triggerall = command = "z"||Command="huttobashi"
triggerall = command != "holddown"
trigger1 = statetype != A && Power>=1000 && Alive
trigger1 = stateno=[150,153]

;---------------------------------------------------------------------------
;�����ړ�
[State -1]
type=null;ChangeState
value=500
triggerall = command = "c"||command = "recovery"
trigger1 = statetype = S
trigger1 = ctrl
trigger2=Stateno=100

;---------------------------------------------------------------------------
;�Ԃ��Ƃ΂�
[State -1]
type=null;ChangeState
value=250
triggerall = command = "z"||Command="huttobashi"
trigger1 = statetype = S
trigger1 = ctrl
trigger2=Stateno=100
;---------------------------------------------------------------------------
;�Ԃ��Ƃ΂�
[State -1]
type=null;ChangeState
value=255
triggerall = command = "z"||Command="huttobashi"
trigger1 = statetype = A
trigger1 = ctrl

;===========================================================================
;---------------------------------------------------------------------------
;������p���`
[State -1]
type=ChangeState
value=ifelse(P2Bodydist X>=10,200,205)
triggerall = command = "x"
trigger1 = statetype = S
trigger1 = ctrl
trigger2=Stateno=100
trigger3=(Stateno=[230,235])&&Time=[5,8]
trigger4=(Stateno=[200,205])&&Time=[4,7]

;---------------------------------------------------------------------------
;������P
[State -1]
type=ChangeState
value=ifelse(P2Bodydist X>=18,210,215)
triggerall = command = "y"
trigger1 = statetype = S
trigger1 = ctrl
trigger2=Stateno=100

;---------------------------------------------------------------------------
;������L�b�N
[State -1, Stand Light Kick]
type = ChangeState
value=ifelse(P2Bodydist X>=10,230,235)
triggerall = command = "a"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl
trigger2=Stateno=100
trigger3=(Stateno=[230,235])&&Time=[5,8]

;---------------------------------------------------------------------------
;�������L�b�N
[State -1, Standing Strong Kick]
type = ChangeState
value=ifelse(P2Bodydist X>=20,240,245)
triggerall = command = "b"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl
trigger2=Stateno=100

;---------------------------------------------------------------------------
;����
[State -1, Taunt]
type = ChangeState
value = 195
triggerall = command = "start"
triggerall = statetype != A
trigger1 = ctrl
trigger2=Stateno=100

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�p���`
[State -1, Crouching Light Punch]
type = ChangeState
value = 400
triggerall = command = "x"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2=Stateno=100
;---------------------------------------------------------------------------
;���Ⴊ�݋��p���`
[State -1, Crouching Strong Punch]
type = ChangeState
value = 410
triggerall = command = "y"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2=Stateno=100

;---------------------------------------------------------------------------
;���Ⴊ�ݎ�L�b�N
[State -1, Crouching Light Kick]
type = ChangeState
value = 430
triggerall = command = "a"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2=Stateno=100
trigger3=(Stateno=430)&&Time=[5,9]

;---------------------------------------------------------------------------
;���Ⴊ�݋��L�b�N
[State -1, Crouching Strong Kick]
type = ChangeState
value = 440
triggerall = command = "b"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2=Stateno=100

;---------------------------------------------------------------------------
;�󒆎�p���`
[State -1, Jump Light Punch]
type = ChangeState
value = 600
triggerall = command = "x"
trigger1 = statetype = A
trigger1 = ctrl

;---------------------------------------------------------------------------
;�󒆋��L�b�N
[State -1, Jump Strong Kick]
type = ChangeState
value=645
triggerall=Stateno=[54,55]
triggerall = command = "b"
trigger1 = statetype = A
trigger1 = ctrl

;---------------------------------------------------------------------------

;---------------------------------------------------------------------------
;�󒆋��p���`
[State -1, Jump Strong Punch]
type = ChangeState
value=610
triggerall = command = "y"
trigger1 = statetype = A
trigger1 = ctrl

;---------------------------------------------------------------------------
;�󒆎�L�b�N
[State -1, Jump Light Kick]
type = ChangeState
value=630
triggerall = command = "a"
trigger1 = statetype = A
trigger1 = ctrl

;---------------------------------------------------------------------------
;�󒆋��L�b�N
[State -1, Jump Strong Kick]
type = ChangeState
value=ifelse(vel X=0,640,645)
triggerall=Stateno!=[54,55]
triggerall = command = "b"
trigger1 = statetype = A
trigger1 = ctrl

;---------------------------------------------------------------------------
